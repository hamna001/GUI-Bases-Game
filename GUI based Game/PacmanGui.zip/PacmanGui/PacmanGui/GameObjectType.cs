﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PacmanGui
{
    enum GameObjectType
    {
        WALL, PLAYER, ENEMY, REWARD, NONE,Key,BULLET,WATER
    }
}
